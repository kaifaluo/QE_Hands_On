rm -rf *.wfc* *.xml *.save *.out *~ CRASH slurm-* *# *.o
