#!/bin/bash -l
# This script links the eqp.dat file into eqp_co.dat

ln -sf ../2-sigma/eqp1.dat eqp_co.dat
