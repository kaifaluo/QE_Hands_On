#!/bin/bash -l

ln -sf ../WFN* ./
ln -sf ../bsemat.h5 ./
ln -sf ../eps*mat.h5 ./
