#!/bin/bash -l

ln -sf ../WFN_co ./
ln -sf wfn_fi/WFN WFN_fi
ln -sf wfnq_fi/WFN WFNq_fi
ln -sf ../bsemat.h5 ./
ln -sf ../eps*mat.h5 ./
ln -sf ../eqp_co.dat ./
