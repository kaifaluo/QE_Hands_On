# Silicon (2) - 2-bgw/1-epsilon

Just like for the mean-field calculations, we won't recalculate the dielectric
matrix, but reuse it from the first silicon example.

Run `./01-reuse-files.sh` to reuse the files from the first session.
