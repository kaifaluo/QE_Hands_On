#!/bin/bash -l
src=$BGW_TUTORIAL/1a-silicon_mfs-run
#src=../../../1a-silicon_mfs

ln -sf $src/2a-bgw-paratec/2-sigma/eqp1.dat .
