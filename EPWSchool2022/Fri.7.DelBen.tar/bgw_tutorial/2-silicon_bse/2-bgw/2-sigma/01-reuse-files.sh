#!/bin/bash -l
# src=$BGW_TUTORIAL/1a-silicon_mfs-run
src=/work2/06868/giustino/EP-SCHOOL/BGW/internal/1-silicon_gw-run/

ln -sf $src/2-bgw/2-sigma/eqp1.dat .
