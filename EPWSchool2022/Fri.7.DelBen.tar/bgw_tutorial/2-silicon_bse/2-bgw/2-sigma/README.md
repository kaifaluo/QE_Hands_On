# Silicon (2) - 2-bgw/2-sigma

We are also not performing another Sigma calculation, but rather using
the QP energies reported in `eqp1.dat` calculated previously.


## Instructions

1. Run `./01-reuse-files.sh` to link the file `eqp1.dat` from the first
   tutorial.
