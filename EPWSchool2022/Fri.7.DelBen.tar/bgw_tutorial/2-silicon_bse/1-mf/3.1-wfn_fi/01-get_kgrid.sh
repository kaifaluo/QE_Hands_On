#!/bin/bash -l

ibrun -np 1     kgrid.x ./kgrid.inp ./kgrid.out ./kgrid.log
