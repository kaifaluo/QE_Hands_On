# Silicon (2) - 1-mf/1-scf

Since you already performed the SCF calculation for Si in the tutorial 1a,
we'll reuse the charge density from your older calculation. We will reuse the
pre-ran solutions from the 1a-silicon example that we ran prior to the
workshop.  However, you can also change the script to reuse the files from your
own previous calculation.

Run `./01-reuse_files.sh` to link the `CD` and `Si_POT.DAT` files. If you wish,
you can update the change the script to link to your own files.
