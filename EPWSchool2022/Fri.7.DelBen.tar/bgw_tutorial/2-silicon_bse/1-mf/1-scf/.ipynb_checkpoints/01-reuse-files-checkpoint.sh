#!/bin/bash -l
src=$BGW_TUTORIAL/1a-silicon_mfs-run
#src=../../../1a-silicon_mfs

ln -sf $src/1a-mf-paratec/1-scf/CD .
ln -sf $src/1a-mf-paratec/1-scf/Si_POT.DAT .
