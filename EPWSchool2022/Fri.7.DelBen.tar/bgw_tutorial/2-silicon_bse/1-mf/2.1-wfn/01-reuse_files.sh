#!/bin/bash -l
# src=$BGW_TUTORIAL/1a-silicon_mfs-run
src=/work2/06868/giustino/EP-SCHOOL/BGW/internal/1-silicon_gw-run/

ln -sf $src/1-mf-qe/2.1-wfn/WFN .
