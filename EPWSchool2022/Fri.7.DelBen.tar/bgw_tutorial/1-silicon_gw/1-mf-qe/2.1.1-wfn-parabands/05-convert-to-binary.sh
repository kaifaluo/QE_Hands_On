#!/bin/bash -l

# module load berkeleygw-tutorial

ibrun -np 1     hdf2wfn.x BIN WFN.h5 WFN
