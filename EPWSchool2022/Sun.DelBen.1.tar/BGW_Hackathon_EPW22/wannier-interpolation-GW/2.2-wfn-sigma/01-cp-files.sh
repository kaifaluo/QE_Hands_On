#!/bin/bash -l

cp -r ../1-scf/Si* .
