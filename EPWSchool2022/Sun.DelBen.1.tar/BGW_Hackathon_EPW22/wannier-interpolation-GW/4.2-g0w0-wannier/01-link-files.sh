ln -s ../2.1-wfn-wannier/Si.amn .
ln -s ../2.1-wfn-wannier/Si.mmn .
ln -s ../2.1-wfn-wannier/Si.chk .

ln -s  ../4.1-g0w0/Si.eqp1.eig  Si.eig
