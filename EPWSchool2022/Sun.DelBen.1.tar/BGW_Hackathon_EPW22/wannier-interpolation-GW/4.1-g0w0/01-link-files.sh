ln -s ../3-epsilon/epsmat.h5 .
ln -s ../3-epsilon/eps0mat.h5 .
ln -s ../2.2-wfn-sigma/vxc.dat .
ln -s ../2.2-wfn-sigma/RHO .
ln -s ../2.2-wfn-sigma/WFN WFN_inner

ln -s ../2.1-wfn-wannier/Si.nnkp
