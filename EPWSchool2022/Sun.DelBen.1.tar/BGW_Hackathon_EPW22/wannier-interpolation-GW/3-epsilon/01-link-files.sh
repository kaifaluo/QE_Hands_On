ln -s ../2.2-wfn-sigma/WFN WFN
ln -s ../2.3-wfnq-sigma/WFN WFNq
